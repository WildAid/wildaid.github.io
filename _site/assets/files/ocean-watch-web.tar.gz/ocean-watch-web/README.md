Installation/configuration instructions:

0. Prerequisites: `git` and `Node.js`
1. `git clone https://github.com/mongodb-appeng/ocean-watch-web`
2. `cd ocean-watch-web`
3. `npm install`
4. Setup the your configuration data in `src/.env/config.js`. For internal MongoDB testing use:
```js
const config = {
    appName: 'ocean-watch-web',
    stitchAppId: 'wildaid-vgfja',
    stitchDatabase: 'wildaid',
    stitchBaseUrl: 'https://stitch-dev.mongodb.com'
}

module.exports = config;
```
5. `npm start`
