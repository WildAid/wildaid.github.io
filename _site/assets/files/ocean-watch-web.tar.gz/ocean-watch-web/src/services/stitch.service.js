import config from "../.env/config";
import {
  Stitch,
  StitchAppClientConfiguration,
  UserPasswordAuthProviderClient,
  UserPasswordCredential,
  RemoteMongoClient,
  BSON
} from "mongodb-stitch-browser-sdk";

export default class StitchService {
  static serviceInstance: StitchService = null;

  static getInstance() {
    if (StitchService.serviceInstance == null) {
      StitchService.serviceInstance = new StitchService();
    }
    return StitchService.serviceInstance;
  }

  get client() {
    return this._localStitchClient;
  }

  get database() {
    return this._database;
  }

  constructor() {
    const stitchConfig = new StitchAppClientConfiguration({
      baseUrl: config.stitchBaseUrl,
    });
    this._localStitchClient = Stitch.initializeDefaultAppClient(
      config.stitchAppId,
      stitchConfig
    );
    this._database = null;
    //this.authenticateStitch();
  }

  reinitializeClient() {
    this._database = this._localStitchClient
      .getServiceClient(RemoteMongoClient.factory, "mongodb-atlas")
      .db(config.stitchDatabase);
  }

  getUser(critheria) {
    if (!this._database) {
      throw new Error("You are not logged in! Please, login first.");
    }
    return this._database.collection("User").findOne(critheria);
  }

  getBoardingById(id) {
    if (!this._database) {
      throw new Error("You are not logged in! Please, login first.");
    }
    if (id.length !== 24){
      throw new Error("Incorrect ID");
    }
    const objectId = new BSON.ObjectId(id);
    return this._database.collection("BoardingReports").findOne({_id: objectId});
  }

  updateBoarding(object){
    if (!this._database) {
      throw new Error("You are not logged in! Please, login first.");
    }
    if (object._id){
      object._id = new BSON.ObjectId(object._id);
      return this._database.collection("BoardingReports").updateOne({
        _id : object._id
      }, object);
    } else {
      return this._database.collection("BoardingReports").insertOne(object);
    }
  }

  getUsers(critheria) {
    if (!this._database) {
      throw new Error("You are not logged in! Please, login first.");
    }
    return this._database.collection("User").find(critheria).toArray();
  }

  searchUsers(emailSearch) {
    if (!this._database) {
      throw new Error("You are not logged in! Please, login first.");
    }
    return this._localStitchClient.callFunction("searchUsers", [emailSearch]);
  }

  authenticateStitch(login, pass) {
    return this._localStitchClient.auth
      .loginWithCredential(new UserPasswordCredential(login, pass))
      .then((user) => {
        this.reinitializeClient();
        return user;
      });
  }

  createUser(login, password, agency) {
    if (!this._database) {
      throw new Error("You are not logged in! Please, login first.");
    }
    return this._localStitchClient.auth
      .getProviderClient(UserPasswordAuthProviderClient.factory)
      .registerWithEmail(login, password)
      .then((result) => {
        return this._database
          .collection("User")
          .findOne({ email: login })
          .then((user) => {
            if (user) {
              return this._database.collection("User").updateOne({
                email: login,
                agency: { name: agency },
                global: { admin: false },
              });
            } else {
              console.error("User does not exists!");
              throw new Error(
                "A user " + login + " registered but not found on DB!"
              );
            }
          });
      });
  }

  getBoardings(limit, offset, filter) {
    return this._localStitchClient.callFunction("getBoardings", [limit, offset, filter]);
  }

  getBoardingsWithFacet(limit, offset, search, filter) {
    return this._localStitchClient.callFunction("searchFacetByBoardings", [limit, offset, search, filter]);
  }

  getData(limit, offset, funcName) {
    return this._localStitchClient.callFunction(funcName, [limit, offset]);
  }
}
