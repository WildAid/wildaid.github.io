//@flow

import React, { Component } from "react";
import { renderRoutes } from "react-router-config";

import Header from "../components/header/header.component";

import "./root.css";

class Root extends Component {
  render() {
    const { route } = this.props;

    return (
      <div className="root">
        <Header />
        <main>{renderRoutes(route.routes)}</main>
      </div>
    );
  }
}

export default Root;
