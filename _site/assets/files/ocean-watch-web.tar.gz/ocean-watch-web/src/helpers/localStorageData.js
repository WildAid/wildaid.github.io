const AUTH_INFO_KEY = "auth_info";
const CURRENT_PAGE_KEY = "general_table_current_page"

class lStorage{
  setItem(key, value){
    return localStorage.setItem(key, JSON.stringify(value));
  }

  getItem(key){
    return JSON.parse(localStorage.getItem(key));
  }

  setAuthInfo(value){
    return this.setItem(AUTH_INFO_KEY, value);
  }

  getAuthInfo(){
    return this.getItem(AUTH_INFO_KEY);
  }

  setCurrentPage(value, page){
    return this.setItem(page + "_" + CURRENT_PAGE_KEY, value);
  }

  getCurrentPage(page){
    return this.getItem(page + "_" + CURRENT_PAGE_KEY);
  }

  clear(){
      localStorage.clear();
  }
}

const instance = new lStorage();

export default instance;
