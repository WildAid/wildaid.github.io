import React, { Component } from "react";

class EditAgency extends Component {
  render() {
    return (
      <div className="edit-agency-page">
        Edit Agency page
      </div>
    );
  }
}

export default EditAgency;
