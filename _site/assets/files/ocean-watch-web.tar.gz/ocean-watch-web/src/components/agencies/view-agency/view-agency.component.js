import React, { Component } from "react";
import { NavLink } from "react-router-dom";

import { agenciesMockedData } from "../agencies.component";

import { EDIT_AGENCIES_PAGE } from "./../../../root/root.constants";

import "./view-agency.css";

class ViewAgency extends Component {
  state = {
    agencyInfo: {
      officers: [],
      catches: [],
      violations: [],
    },
    activeTab: 1,
  };

  handleChangeTab = (newTab) => {    
    this.setState({
      activeTab: newTab,
    });
  };

  componentDidMount() {
    const currentId = this.props.match.params.id;

    this.setState({
      agencyInfo: agenciesMockedData.find((el) => el.id === currentId),
    });
  }

  render() {
    const { agencyInfo, activeTab } = this.state;
    
    return (
      <div className="view-agency-page">
        <div className="agency-header">
          <div className="agency-main-info">
            <div className="agency-label">Agency</div>
            <div className="agency-name">{agencyInfo.agency}</div>
            <div className="agency-description">{agencyInfo.description}</div>
            <div className="agency-box">
              <div className="img-container">
                <img
                  className="icon"
                  src={require("../../../assets/site-icon.png")}
                  alt="no logo"
                />
              </div>
              {agencyInfo.site}
            </div>
            <div className="agency-box">
              <div className="img-container">
                <img
                  className="icon"
                  src={require("../../../assets/email-icon.png")}
                  alt="no logo"
                />
              </div>
              {agencyInfo.email}
            </div>
          </div>
          <NavLink className="new-agencies-link" to={EDIT_AGENCIES_PAGE}>
            <button className="panel-btn">Edit Agency Information</button>
          </NavLink>
        </div>
        <div className="agency-part-info">
          <div className="agency-tabs">
            <div
              className={`tab ${1 === activeTab ? "active-tab" : ""}`}
              onClick={() => this.handleChangeTab(1)}
            >
              Officers
            </div>
            <div
              className={`tab ${2 === activeTab ? "active-tab" : ""}`}
              onClick={() => this.handleChangeTab(2)}
            >
              Form Data
            </div>
          </div>
          <div className="agency-content">
            {1 === activeTab ? (
              <div className="content">
                <table className="officers-table">
                  <thead>
                    <tr className="string string-head">
                      <td>
                        <div className="box table-header">
                          <div className="name">
                            Officers {`(${agencyInfo.officers.length})`}
                          </div>
                          <button className="btn">
                            Create Activity Report
                          </button>
                        </div>
                      </td>
                    </tr>
                  </thead>
                  <tbody>
                    {agencyInfo.officers.map((officer, ind) => (
                      <tr className="string string-body" key={ind}>
                        <td>
                          <div className="box">
                            <div className="img-container">
                              <img
                                className="icon"
                                src={require("../../../assets/crew-icon.png")}
                                alt="no logo"
                              />
                            </div>
                            {officer.name}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="content">
                <div className="form-box">
                  <div className="form-menu">
                    <div className="form-menu-item active-item">
                      Catch {`(${agencyInfo.catches.length})`}
                    </div>
                    <div className="form-menu-item">
                      Violations {`(${agencyInfo.violations.length})`}
                    </div>
                    <div className="form-menu-item">
                      Prefered Nationatities {`(${agencyInfo.officers.length})`}
                    </div>
                  </div>
                  <div className="form-search">
                    <div className="form-search-panel">
                      <input
                        className="form-search-field"
                        type="search"
                        placeholder="Search Species"
                      ></input>
                      <button className="panel-btn">+ Add species</button>
                    </div>
                    <div className="form-checkbox-list">
                      {agencyInfo.catches.map((item, ind) => (
                        <div className="box" key={ind}>
                          <input
                            className="check-item"
                            type="checkbox"
                          />
                          {item.name}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default ViewAgency;
