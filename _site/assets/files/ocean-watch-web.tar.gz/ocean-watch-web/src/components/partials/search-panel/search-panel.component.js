import React, { Component } from "react";
import { Grid } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";

import CustomSelect from "./../custom-select/custom-select";

import "./search.css";

class SearchPanel extends Component {
  state = {
    searchQuery: "",
  };

  setSearch = (event) => {
    const { value } = event.target;
    const { handler } = this.props;

    this.setState({ searchQuery: value });

    if (this.debounceInterval) {
      clearInterval(this.debounceInterval);
    }

    this.debounceInterval = setTimeout(() => {
      if (handler) {
        handler(value);
      }
      this.debounceInterval = null;
    }, 100);
  };

  render() {
    return (
      <Grid
        className="search-panel"
        container
        justify="center"
        alignItems="center"
      >
        <Grid item sm={10} md={10} lg={10}>
          <div className="search">
            <div className="search-icon">
              <SearchIcon />
            </div>
            <input
              className="search-field"
              type="search"
              placeholder="Search Ocean Watch"
              value={this.state.searchQuery || this.props.value || ''}
              onChange={this.setSearch}
            ></input>
            <CustomSelect />
          </div>
        </Grid>
      </Grid>
    );
  }
}

export default SearchPanel;
