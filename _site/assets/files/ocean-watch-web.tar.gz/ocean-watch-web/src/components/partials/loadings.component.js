import React, { Component } from "react";

export default class LoadingsComponent extends Component {
  render(){
    return (
      <div className='loading-panel'>
        <div className="loading-indicator"></div>
      </div>
    )
  }
}
