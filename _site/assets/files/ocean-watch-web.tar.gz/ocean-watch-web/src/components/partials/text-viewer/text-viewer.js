import React, { memo } from "react";
import Highlighter from "react-highlight-words";


import "./text-viewer.css";

const TextViewer = ({ mainText, subText, searchWords }) => (
  <div className="text">
    <div className="sub-text">{subText}</div>
    <div className="main-text">
      <Highlighter
        highlightClassName="highlighted"
        searchWords={searchWords || []}
        autoEscape={true}
        textToHighlight={mainText}
      />
    </div>
  </div>
);

export default memo(TextViewer);
