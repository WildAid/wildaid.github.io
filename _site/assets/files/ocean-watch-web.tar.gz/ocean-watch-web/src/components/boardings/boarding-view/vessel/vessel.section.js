import React, { Component } from "react";
import TextField from "../text-field.component"


export default class VesselSection extends Component {
  setFieldValue = (name, value) => {

  }

  render() {
    const {vessel} = this.props.dataObject;
    const ems = vessel.ems && vessel.ems.length ? vessel.ems[0] : {};
    const lastDelivery = vessel.lastDelivery || {};
    return (
      <div className='vessel-section section'>
        <h2>Vessel</h2>
        <section className="row">
          <div>
            <h3>Vessel Information</h3>
              <div>
                <TextField label="Vessel Name" name="name" value={vessel.name} />
                <TextField label="Home Port" name="home_port" value={vessel.homePort} />
                <TextField label="Permit Number"  name="permit_number" value={vessel.permitNumber} />
                <TextField label="Nationality" name="nationality" value={vessel.nationality} />
              </div>
          </div>
          <div>
            <h3>Last Date of delivery</h3>
            <div>
              <TextField label="Date"     value={lastDelivery.date}/>
              <TextField label="Location" value={lastDelivery.location}/>
              <TextField label="Business" value={lastDelivery.business}/>
            </div>
            </div>
            <div>
              <h3>Electronic Monitoring System</h3>
              <div>
                <TextField label="Type" name="ems-type" value={ems.emsType}/>
                <TextField label="Registry Number" name="ems-registry" value={ems.RegistryNumber}/>
                <TextField label="Description" name="ems-Description" value={ems.emsDescription}/>
              </div>
            </div>
          </section>
      </div>
  )
}
}
