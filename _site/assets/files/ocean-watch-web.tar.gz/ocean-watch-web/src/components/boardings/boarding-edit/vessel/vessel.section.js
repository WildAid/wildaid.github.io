import React, { Component } from "react";
import {TextField} from '@material-ui/core';


export default class VesselSection extends Component {
  state = {
    vessel:{
      name: '',
      permitNumber: '',
      homePort: '',
      nationality: '',
      lastDelivery: {
        date: '',
        business: '',
        location: ''
      },
      ems: [
        {
          type: "",
          registry: "",
          description: ""
        }
      ]
    },
  }

  componentDidMount(){
    const {vessel} = this.state;
    if (this.props.dataObject && this.props.dataObject.vessel){
      this.setState({
        vessel: this.props.dataObject.vessel
      })
    }
  }

  setFieldValue = (name, value) => {
    const {vessel} = this.state;
    vessel[name] = value;
    this.setState({
      vessel: vessel
    });
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.vessel = vessel;
      this.props.onChange(dataObject);
    }
  }

  setEmsFieldValue = (name, value) => {
    const {vessel} = this.state;
    if (!vessel.ems || vessel.ems.length === 0) vessel.ems = [{
      type: "",
      registry: "",
      description: ""
    }];
    vessel.ems[0][name] = value;
    this.setState({
      vessel: vessel
    });
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.vessel = vessel;
      this.props.onChange(dataObject);
    }
  }

  setLdodFieldValue = (name, value) => {
    const {vessel} = this.state;
    if (!vessel.lastDelivery) vessel.lastDelivery = {
      date: '',
      business: '',
      location: ''
    };
    vessel.lastDelivery[name] = value;
    this.setState({
      vessel: vessel
    });
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.vessel = vessel;
      this.props.onChange(dataObject);
    }
  }

  render() {
      const {vessel} = this.state;
      const lastDelivery = vessel && vessel.lastDelivery ? vessel.lastDelivery: {}
      const ems = vessel && vessel.ems && vessel.ems[0] ? vessel.ems[0] : {}
      return (
        <div className='vessel-section section'>
          <section>
            <h3>Vessel Information</h3>
              <div className="row">
                <TextField label="Vessel Name:" className="half-row" name="name" value={vessel.name}  onChange={e => this.setFieldValue("name", e.target.value)}/>
                <TextField label="Home Port:" className="half-row" name="homePort" value={vessel.homePort} onChange={e => this.setFieldValue("homePort", e.target.value)}/>
              </div>
              <div className="row">
                <TextField label="Permit Number:" className="half-row"  name="permitNumber" value={vessel.permitNumber} onChange={e => this.setFieldValue("permitNumber", e.target.value)}/>
                <TextField label="Nationality:" className="half-row" name="nationality" value={vessel.nationality} onChange={e => this.setFieldValue("nationality", e.target.value)}/>
              </div>
          </section>
          <section>
            <h3>Last Date of delivery</h3>
            <div className="row">
              <TextField label="Date:" className="half-row" name="ldod_date" value={lastDelivery.date}  onChange={e => this.setLdodFieldValue("date", e.target.value)}/>
              <TextField label="Location:" className="half-row" name="ldod_location" value={lastDelivery.location} onChange={e => this.setLdodFieldValue("location", e.target.value)}/>
            </div>
            <div className="row">
              <TextField label="Business:" className="half-row"  name="ldod_business" value={lastDelivery.business} onChange={e => this.setLdodFieldValue("business", e.target.value)}/>
            </div>
            </section>
            <section>
              <h3>Electronic Monitoring Information</h3>
              <div className="row">
                <TextField label="Type:" className="half-row" name="ems-type" value={ems.type} onChange={e => this.setEmsFieldValue("type", e.target.value)}/>
                <TextField label="Registry Number:" className="half-row" name="ems-registry" value={ems.registry} onChange={e => this.setEmsFieldValue("registry", e.target.value)}/>
              </div>
              <div className="row">
                <TextField label="Description:" className="half-row" name="ems-description" value={ems.description} onChange={e => this.setEmsFieldValue("description", e.target.value)}/>
              </div>
            </section>
        </div>
    )
  }
}
