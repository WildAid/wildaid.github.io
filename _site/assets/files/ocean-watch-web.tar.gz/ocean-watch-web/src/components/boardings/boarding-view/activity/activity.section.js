import React, { Component } from "react";
import TextField from "../text-field.component"

export default class ActivitySection extends Component {
  render() {
    const {inspection} = this.props.dataObject;
    console.log(inspection);
    //const gear = inspection.gearType && inspection.gearType.length ? inspection.gearType[0] : ""
    const activity = inspection.activity && inspection.activity.name ? inspection.activity.name : inspection.activity;
    const fishery = inspection.fishery && inspection.fishery.name ? inspection.fishery.name : inspection.fishery;
    const gearType = inspection.gearType && inspection.gearType.name ? inspection.gearType.name : inspection.gearType;

    return (
        <div className='activity-section section'>
          <h2>Activity</h2>
          <section className="row">
          <div>
            <h3>Activity</h3>
              <div>
                  <TextField label="Activity"     value={activity}/>
              </div>
          </div>
          <div>
            <h3>Fishery</h3>
            <div>
                <TextField label="Fishery"     value={fishery}/>
            </div>
          </div>
          <div>
              <h3>Gear</h3>
              <div>
                  <TextField label="Gear"     value={gearType}/>
              </div>
            </div>
            </section>
        </div>
    )
  }
}
