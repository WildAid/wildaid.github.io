import React from "react";
import { Component } from "react";
import { Button } from '@material-ui/core';

import BasicInfoSection from './basic-info/basic-info.section';
import VesselSection from './vessel/vessel.section';
import CrewSection from './crew/crew.section';
import ActivitySection from './activity/activity.section';
import CatchSection from './catch/catch.section';
import ViolationsSection from './violations/violations.section';
import SeizuresSection from './seizures/seizures.section';
import RisksSection from './risks/risks.section';
import NotesSection from './notes/notes.section';
import VersionControlPanel from '../version-control/version-control.panel'

import './boardings-view.css'

import history from "../../../root/root.history";
import { EDIT_BOARDING_PAGE } from "../../../root/root.constants.js";

import StitchService from "./../../../services/stitch.service";
const stitchService = StitchService.getInstance();

const sampleRevisionHistory = [
  {
    date: "3/10/2019",
    author: "Mike Waltzer",
    changes: [

    ]
  },
  {
    date: "2/11/2019",
    author: "Officer Bob",
    changes: [

    ]
  },
]

class BoardingViewPage extends Component {
  state = { boarding : null, versionsVisible : false }

  componentDidMount(){
    const id = this.props.match.params.id;
    console.log(1);
    
    stitchService
      .getBoardingById(id)
      .then((data) => {
        this.setState({
          boarding: data,
        });
      })
      .catch((error) => {
        console.error(error);
      });
  }

  goEdit = () => {
    history.push(EDIT_BOARDING_PAGE.replace(":id", this.state.boarding._id));
  }

  showVersions = () => {
    this.setState({versionsVisible: true});
  }

  render() {
    const {boarding, versionsVisible} = this.state;
    const lastdate = boarding ? new Date(boarding.date) : new Date();
    return (
      <div className='boarding-view-page'>
        <div className="page-title">
          <div className="row" style={{padding: "10px 2em"}}>
            <div className="half-row">
              <label>Boarding</label>
              <h1 style={{marginTop: "0px"}}>{lastdate.toLocaleDateString()}</h1>
            </div>
            <div className="half-row right-aligned">
              <Button variant="contained" color="primary" onClick={this.goEdit}>Edit Boarding</Button><br/>
              <label style={{paddingTop: "0.7em"}} onClick={this.showVersions}>Last Modified on {lastdate.toLocaleDateString()} by Officer Krupke</label>
              {versionsVisible &&
                <VersionControlPanel
                  dataObject={sampleRevisionHistory}
                  onHide={()=>this.setState({versionsVisible: false})}>
                </VersionControlPanel>}
            </div>
          </div>
        </div>
        {boarding ? (
        <div className="sections">
          <BasicInfoSection dataObject={boarding}></BasicInfoSection>
          <VesselSection dataObject={boarding}></VesselSection>
          <CrewSection dataObject={boarding}></CrewSection>
          <ActivitySection dataObject={boarding}></ActivitySection>
        </div>) : "No object found"}
      </div>
    )
  }
}

  //<CatchSection dataObject={this.state.dataObject}></CatchSection>
  //<SeizuresSection dataObject={this.state.dataObject}></SeizuresSection>
  //  <ViolationsSection dataObject={this.state.dataObject}></ViolationsSection>
  //<RisksSection dataObject={this.state.dataObject}></RisksSection>
  //<NotesSection dataObject={this.state.dataObject}></NotesSection>
export default BoardingViewPage;
