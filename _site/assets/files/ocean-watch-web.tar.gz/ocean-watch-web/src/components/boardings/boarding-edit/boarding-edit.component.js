import React from "react";
import { Component } from "react";
import { Button } from '@material-ui/core';
import { Formik, Form } from "formik";
import { withRouter } from "react-router";

import BasicInfoSection from './basic-info/basic-info.section';
import VesselSection from './vessel/vessel.section';
import CrewSection from './crew/crew.section';
import ActivitySection from './activity/activity.section';
import CatchSection from './catch/catch.section';
import ViolationsSection from './violations/violations.section';
import SeizuresSection from './seizures/seizures.section';
import RisksSection from './risks/risks.section';
import NotesSection from './notes/notes.section';

import './boardings-edit.css'

import history from "../../../root/root.history";
import { VIEW_BOARDING_PAGE } from "../../../root/root.constants.js";

import StitchService from "./../../../services/stitch.service";
const stitchService = StitchService.getInstance();

const initialState =  {
  date: new Date(),
  time: new Date(),
  lattitude: "-0.02182981",
  longtitude: "-0.041231987",
  agency: "WildAid",
  vessel:{
    name: '',
    permitNumber: '',
    homePort: '',
    nationality: '',
    lastDelivery: {
      date: '',
      business: '',
      location: ''
    },
  },
  captain:{
    name: "",
    license: ""
  },
  crew:[
    {
      name: "",
      id: "",
      photoID:"",
      license:""
    }
  ],
  inspection:{
    activity: {
      name: ""
    },
    fishery: {
      name: ""
    },
    gearType: {
      name: ""
    },
    summary: {
      safetyLevel: "amber",
      violations: [
        {
          description: "Arrest of Norby Beauman",
          disposition:"Arrest"
        },
        {
          description: "Warning to Bob Beauman",
          disposition:"Warning"
        }
      ],
      seizures: [
        {
          name: "Norby Beauman",
          id: "429-76-9929",
          photoID:"5e578afce916a14463379bfe",
          license:"Norby Beauman"
        }
      ],
    },
    actualCatch: [
      {
        name: "Norby Beauman",
        id: "429-76-9929",
        photoID:"5e578afce916a14463379bfe",
        license:"Norby Beauman"
      }
    ],
    risk: {
      type: "warning"
    },
    notes: [
      {
        note: "Norby Beauman"
      }
    ]
  },
  reportingOfficer: {
    agency: "WildAid",
    name: {
      first: "",
      last: ""
    }
  }
};

class BoardingEditPage extends Component {
  state = {dataObject: null};

  componentDidMount(){
    const id = this.props.match.params.id;
    if (!id){
      this.setState({
        isNew: true,
        dataObject: initialState
      })
      this.dataObject = initialState;
    } else {
      stitchService
      .getBoardingById(id)
      .then((data) => {
        console.log("Data: ", data);
        this.setState({
          isNew: false,
          dataObject: data
        });
        this.dataObject = data;
      })
      .catch((error) => {
        console.error(error);
      });
    }
  }

  onSubmit = () => {
    console.log("Updating", this.dataObject);
    stitchService.updateBoarding(this.dataObject).then((result)=>{
      console.log("UpdatedObject", result);
      if (this.state.isNew){
        history.push(VIEW_BOARDING_PAGE.replace(":id", result.insertedId));
      } else {
        history.push(VIEW_BOARDING_PAGE.replace(":id", this.state.dataObject._id));
      }
    });
  }

  handleDataChange = (newObject) => {
    this.dataObject = newObject;
  }

  render() {
    const {dataObject} = this.state;
    return (
      <div className='boarding-edit-page'>
        <div className='page-wrapper'>
          <div className="flex-row" style={{padding: "10px 2em"}}>
            <div className="half-row">
              <label>Boarding</label>
              <h1 style={{marginTop: "0px"}}>{(new Date(dataObject ? dataObject.date : null)).toLocaleString()}</h1>
            </div>
            <div className="half-row right-aligned">
              <Button variant="contained" color="primary" onClick={this.onSubmit}>Save Boarding</Button><br/>
              <label style={{paddingTop: "0.7em"}}>Last Modified on {(new Date(dataObject ? dataObject.date : null)).toLocaleString()} by Officer Krupke</label>
            </div>
          </div>
          {this.state.dataObject ? (
            <div className="sections">
              <BasicInfoSection dataObject={dataObject} onChange={this.handleDataChange}></BasicInfoSection>
              <VesselSection dataObject={dataObject} onChange={this.handleDataChange}></VesselSection>
              <CrewSection dataObject={dataObject} onChange={this.handleDataChange}></CrewSection>
              <ActivitySection dataObject={dataObject} onChange={this.handleDataChange}></ActivitySection>
            </div>) : "No object found"}
          </div>
        </div>
      )
    }
  }

  //
  //<CatchSection dataObject={this.state.dataObject}></CatchSection>
  //<SeizuresSection dataObject={this.state.dataObject}></SeizuresSection>
  //  <ViolationsSection dataObject={this.state.dataObject}></ViolationsSection>
  //<RisksSection dataObject={this.state.dataObject}></RisksSection>
  //<NotesSection dataObject={this.state.dataObject}></NotesSection>
  export default withRouter(BoardingEditPage);
