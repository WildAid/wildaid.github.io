import React, { Component } from "react";
import TextField from "../text-field.component"
import './crew-section.css';

export default class CrewSection extends Component {

  constructor(props){
    super(props);
    this.state = {
      count: props.count,
      crew: props.dataObject.crew,
      captain: props.dataObject.captain
    }
  }

  setFieldValue = (name, value) => {

  }

  addNew = (name, value) => {
    const newCrew = [...this.state.crew];
    newCrew.push({});
    this.setState({crew: newCrew});
  }

  deleteItem(itemNo) {
    const newCrew = [...this.state.crew];
    newCrew.splice(itemNo - 1);
    this.setState({crew: newCrew});
  }

  render() {
    const {crew, captain} = this.state;
    return (
      <div className='crew-section section'>
        <h2>Captain</h2>
        <section className='row'>
          <TextField label="Name"     value={captain.name}/>
          <TextField label="License Number" value={captain.licenseNumber}/>
          <TextField label="Photos" value=""/>
          <TextField label="Notes" value={captain.notes}/>
        </section>
        <h2>Crew</h2>
          <section>
              <div className="row">
                <TextField label="Name"/>
                <TextField label="License Number"/>
                <TextField label="Photos"/>
                <TextField label="Notes"/>
              </div>
              {crew.map((item, ind) => (
                <div className="row" key={ind}>
                  <TextField value={item.name}/>
                  <TextField value={item.license}/>
                  <TextField value={""}/>
                  <TextField value={item.other && item.other.map(o=>'').join(',')}/>
                </div>
              ))}
          </section>
      </div>
  )
}
}
