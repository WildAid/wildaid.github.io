import React, { Component } from "react";


export default class SeizuresSection extends Component {

  render() {
    return (
      <div class='crew-section'>
        <div className="row left-aligned" style={{width:"60%", margin: 0, padding: "10px 2em"}}>
          <h2 style={{marginTop: 0}}>Seizures</h2>
        </div>
      </div>
  )
}
}
