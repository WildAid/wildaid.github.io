import React, { Component } from "react";
import {Button, TextField} from '@material-ui/core';
import Icon from '@material-ui/core/Icon';

export default class CrewSection extends Component {
  state = { count: 0, crew : [], captain : {name: "", license: ""}}

  componentDidMount(){
    this.setState({
      count: this.props.count,
      crew: this.props.dataObject.crew,
      captain : this.props.dataObject.captain
    })
  }

  setCaptain = (field, value) => {
    const {captain} = this.state;
    captain[field] = value;
    this.setState({
      captain : captain
    });
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.captain = captain;
      this.props.onChange(dataObject);
    }
  }

  setFieldValue = (index, name, value) => {
    const {crew} = this.state;
    crew[index][name] = value;
    this.setState({
      crew : crew
    });
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.crew = crew;
      this.props.onChange(dataObject);
    }
  }

  addNew = (name, value) => {
    const newCrew = [...this.state.crew];
    newCrew.push({});
    this.setState({crew: newCrew});
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.crew = newCrew;
      this.props.onChange(dataObject);
    }
  }

  deleteItem(itemNo) {
    const newCrew = [...this.state.crew];
    newCrew.splice(itemNo - 1);
    this.setState({crew: newCrew});
    if (this.props.onChange){
      const {dataObject} = this.props;
      dataObject.crew = newCrew;
      this.props.onChange(dataObject);
    }
  }

  render() {
    const {crew, captain} = this.state;
    return (
      <div className='crew-section section'>
        <div className="flex-row title-row" style={{padding: "10px 2em"}}>
          <h2 style={{marginTop: 0}}>Captain</h2>
        </div>
        <section>
            <div className="flex-row row">
              <h3>Captain</h3>
              <div className='section-buttons'>
                <Button variant="outlined">
                  <Icon>attachment</Icon>
                </Button>
              </div>
            </div>
            <div className="flex-row row">
              <TextField label="Name:" name="name" value={captain.name} className="half-row" onChange={e => this.setCaptain("name", e.target.value)}/>
              <TextField label="License number:" name="license"  className="half-row" value={captain.license} onChange={e => this.setCaptain("license", e.target.value)}/>
            </div>
        </section>
        <div className="flex-row title-row">
          <h2 style={{marginTop: 0}}>Crew</h2>
          <div className="add-link">
            <Button onClick={this.addNew}>
              <Icon>add</Icon>
              <span>Add crew member</span>
            </Button>
          </div>
        </div>
        {crew.map((item, index) => (
          <section key={index}>
              <div className="flex-row row">
                <h3>Crew member {index + 1}</h3>
                <div className='section-buttons'>
                  <Button variant="outlined" onClick={()=>this.deleteItem(index)}>
                    <Icon>delete_outlined</Icon>
                  </Button>
                  <Button variant="outlined">
                    <Icon>attachment</Icon>
                  </Button>
                </div>
              </div>
              <div className="flex-row row">
                <TextField label="Name:" name="name" value={item.name} className="half-row" onChange={e => this.setFieldValue(index, "name", e.target.value)}/>
                <TextField label="License number:" name="license"  className="half-row" value={item.license} onChange={e => this.setFieldValue(index, "license", e.target.value)}/>
              </div>
          </section>
        ))}
      </div>
  )
}
}
