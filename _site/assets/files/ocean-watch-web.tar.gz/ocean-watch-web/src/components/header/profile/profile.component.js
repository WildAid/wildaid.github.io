import React, { memo } from "react";

import AuthService from "../../../services/auth.service";

import "./profile.css";

const authService = AuthService.getInstance();

const Profile = ({ value, iconStyle }) => (
  <div className="profile-info">
    <div className="profile-img">
      <img
        className="profile-icon"
        src={require("../../../assets/user-icon.png")}
        alt="no logo"
      />
    </div>
    <div className="profile-name">
      {(authService.isAuthenticated ? authService.user.profile.data.email : "Not authenticated!")}
    </div>
  </div>
);

export default memo(Profile);
