import React, { memo, Fragment } from "react";
import { withRouter } from "react-router";
import { NavLink } from "react-router-dom";

import { NAVIGATION } from "./navigation.constants";

import { resetSearch } from './../../../helpers/get-data';

import "./navigation.css";

const Navigation = () => {  
  return (
    <Fragment>
      {NAVIGATION.map((item, ind) => (
        <NavLink onClick={() => resetSearch()} key={ind} className="nav-link" to={item.path}>
          {item.name}
        </NavLink>
      ))}
    </Fragment>
  );
};

export default withRouter(memo(Navigation));
