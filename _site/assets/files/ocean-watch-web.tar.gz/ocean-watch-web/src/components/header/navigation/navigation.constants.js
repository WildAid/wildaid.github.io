import {
  HOME_PAGE,
  BOARDINGS_PAGE,
  VESSELS_PAGE,
  CREW_PAGE,
  USERS_PAGE,
  AGENCIES_PAGE,
  FORMS_PAGE,
} from "../../../root/root.constants.js";

export const NAVIGATION = [
  {
    name: "Home",
    path: HOME_PAGE,
  },
  {
    name: "Boardings",
    path: BOARDINGS_PAGE,
  },
  {
    name: "Vessels",
    path: VESSELS_PAGE,
  },
  {
    name: "Crew",
    path: CREW_PAGE,
  },
  {
    name: "Users",
    path: USERS_PAGE,
  },
  {
    name: "Agencies",
    path: AGENCIES_PAGE,
  },
  {
    name: "Forms",
    path: FORMS_PAGE,
  },
];
