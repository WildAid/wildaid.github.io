import React, { Component } from "react";
import { withRouter } from "react-router";
import { NavLink } from "react-router-dom";

import AuthService from "../../services/auth.service";
import Navigation from "./navigation/navigation.component";
import Profile from "./profile/profile.component";

import { HOME_PAGE } from "./../../root/root.constants";

import "./header.css";

const authService = AuthService.getInstance();

class Header extends Component {
  render() {
    return (
      <header className="header-top">
        <NavLink className="nav-link" to={HOME_PAGE}>
          <div className="logo">
            <img
              className="logo-img"
              src={require("../../assets/logo.png")}
              alt="no logo"
            />
          </div>
        </NavLink>
        {!!authService.isAuthenticated && <Navigation />}
        {!!authService.isAuthenticated && <Profile />}
      </header>
    );
  }
}

export default withRouter(Header);
