import React, { Component } from "react";

class EditUser extends Component {
  render() {
    return (
      <div className="edit-user-page">
        Edit User page
      </div>
    );
  }
}

export default EditUser;
