import React, { Component } from "react";
import { Formik, Form } from "formik";
import { TextField } from "@material-ui/core";

import "./new-user.css";

class NewUser extends Component {
  state = {
    newUser: {
      name: "",
      agency: "",
      email: "",
      password: "",
      adminType: "",
    },
  };

  saveUser = (values) => {
    //TO DO - add request and get data to render
  };

  render() {
    return (
      <div className="new-user-page">
        <div className="new-user-header">
          <div>
            <div className="agency-label">User</div>
            <div className="agency-name">New User</div>
          </div>
        </div>
        <div className="new-user-form">
          <Formik
            initialValues={{
              name: "",
              agency: "",
              adminType: "",
              email: "",
              password: "",
            }}
            onSubmit={this.saveAgency}
            render={({
              errors,
              values,
              handleChange,
              handleBlur,
              handleSubmit,
              setFieldValue,
            }) => (
              <Form onSubmit={handleSubmit}>
                <div className="new-user-box">
                  <div className="img-container">
                    <img
                      className="icon"
                      src={require("../../../assets/download-img-icon.jpg")}
                      alt="no logo"
                    />
                  </div>
                </div>
                <div className="new-user-box">
                  <TextField
                    label="Name"
                    name="name"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={(e) => setFieldValue("name", e.target.value)}
                    type="text"
                    value={values.name}
                  />
                  <TextField
                    label="Agency"
                    name="agency"
                    type="text"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={(e) => setFieldValue("agency", e.target.value)}
                    value={values.agency}
                  />
                  <TextField
                    label="Admin Type"
                    name="adminType"
                    type="text"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={(e) => setFieldValue("adminType", e.target.value)}
                    value={values.adminType}
                  />
                </div>
                <div className="new-user-box">
                  <TextField
                    label="Email"
                    name="email"
                    type="text"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={(e) => setFieldValue("email", e.target.value)}
                    value={values.email}
                  />
                  <TextField
                    label="Password"
                    name="password"
                    type="text"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={(e) => setFieldValue("password", e.target.value)}
                    value={values.password}
                  />
                </div>
                <button
                  className="panel-btn"
                  type="submit"
                  onClick={this.saveAgency}
                >
                  Save
                </button>
                <button
                  className="cancel-btn"
                  type="submit"
                  // onClick={this.clearForm}
                >
                  Cancel
                </button>
              </Form>
            )}
          />
        </div>
      </div>
    );
  }
}

export default NewUser;
