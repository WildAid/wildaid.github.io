import React, {memo} from "react";
import ChartBox from './../../charts/chart-box.component';

import "./section.css";

const chartOptions1 = {
  chartId: "f9cd1d83-87dd-4897-927b-9b0d3ddbe53a",
  width: "100%",
  height: "100%",
  refreshInterval: 1300,
  useAuthenticatedAccess: true
};

const chartOptions2 = {
  chartId: "8dedf063-cf39-46be-a5be-4ba7d6e8cbf5",
  width: "100%",
  height: "100%",
  refreshInterval: 1300,
  useAuthenticatedAccess: true
};

const chartOptions3 = {
  chartId: "a2326d88-0a5e-4619-8266-9a653636d5a7",
  width: "100%",
  height: "100%",
  refreshInterval: 1300,
  useAuthenticatedAccess: true
};

const chartOptions4 = {
  chartId: "6562e085-7336-473f-b3f0-0a36c06d4a00",
  width: "100%",
  height: "100%",
  refreshInterval: 1300,
  useAuthenticatedAccess: true
};

const ComplianceRateSection = () => {
  return (
    <section className="charts-section">
      <h2>Compliance Rate</h2>
      <div className="chart-row row">
        <div className="half-row">
          <div className="quad-row compliance-rate-value">
            <ChartBox options={chartOptions4}></ChartBox>
          </div>
          <div className="row flex-row quad-row">
            <div className="half-row">
              <ChartBox options={chartOptions1}></ChartBox>
            </div>
            <div className="half-row">
              <ChartBox options={chartOptions2}></ChartBox>
            </div>
          </div>
        </div>
        <div className="half-row">
          <ChartBox options={chartOptions3}></ChartBox>
        </div>
      </div>
    </section>
  );
};

export default memo(ComplianceRateSection);
