import React, {Component} from "react";
import ChartBox from "./../../charts/chart-box.component";
import FilterPanel from "./../../partials/filter-panel/filter-panel.component";

import "./section.css";

const chartOptions = {
  chartId: "ae81f377-783c-491f-9764-6c8f36a90c12",//"ae81f377-783c-491f-9764-6c8f36a90c12",
  width: "100%",
  height: "100%",
  refreshInterval: 1300,
  useAuthenticatedAccess: true
};

const filterConfiguration = {
  "Date & Time": [
    {
      name: "date",
      title: "Date",
      type: "date"
    },
  ],
  "Agency": [
    {
      name: "agency",
      title: "Name",
      partTitle: "Agency"
    }
  ]
}

export default class PatrolHoursSection extends Component {
    state = {filter : ''}

    filterChanged = (value)=>{
      chartOptions.filter = value;
      this.setState({filter: value});
    }

    render(){
      return (
        <section className='charts-section patrol-hours-section'>
          <div className="flex-row" >
            <h2>Officer Patrol Hours</h2>
            <div style={{marginRight: "7em"}}>
            <FilterPanel
              options={{useChartsSyntax: true}}
              configuration={filterConfiguration}
              onFilterChanged={(value)=>this.filterChanged(value)}>
            </FilterPanel>
            </div>
          </div>
          <div className="chart-row">
            <ChartBox options={chartOptions}></ChartBox>
          </div>
        </section>
      );
    }
}
