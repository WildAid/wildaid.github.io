import React, { Component } from "react";
import ChartBox from "./../../charts/chart-box.component";
import FilterPanel from "./../../partials/filter-panel/filter-panel.component";
import "./section.css";

const chartOptions = {
  chartId: "3f39ac12-c1d2-4549-9ce2-88992db38278",
  width: "100%",
  height: "100%",
  refreshInterval: 1300,
  useAuthenticatedAccess: true
};

const filterConfiguration = {
  "Date & Time": [
    {
      name: "date",
      title: "Date",
      type: "date"
    },
  ],
  "Agency": [
    {
      name: "agency",
      title: "Name",
      partTitle: "Agency"
    }
  ]
}

class BoardingsSection extends Component {
    state = {filter : ''}

    filterChanged = (value)=>{
      chartOptions.filter = value;
      this.setState({filter: value});
    }

    render(){
    return (
      <section className='charts-section boarding-section'>
        <div className="flex-row" >
          <h2>Boardings</h2>
          <div style={{marginRight: "7em"}}>
          <FilterPanel
            options={{useChartsSyntax: true}}
            configuration={filterConfiguration}
            onFilterChanged={(value)=>this.filterChanged(value)}>
          </FilterPanel>
          </div>
        </div>
        <div className="chart-row row">
          <ChartBox options={chartOptions}></ChartBox>
        </div>
      </section>
    );
  }
}

export default BoardingsSection;
