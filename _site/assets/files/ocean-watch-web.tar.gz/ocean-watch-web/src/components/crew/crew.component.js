import React, { Component, Fragment } from "react";
import moment from "moment";
import Pagination from "@material-ui/lab/Pagination";
import Highlighter from "react-highlight-words";

import {
  getColor,
  getRanks,
  getHighlightedText,
} from "./../../helpers/get-data";
import storage from "./../../helpers/localStorageData";

import SearchPanel from "./../partials/search-panel/search-panel.component";

import SearchService from "./../../services/search.service";
import StitchService from "./../../services/stitch.service";

import "./crew.css";

const searchService = SearchService.getInstance();
const stitchService = StitchService.getInstance();

const offset = storage.getCurrentPage() || 1;

class Crew extends Component {
  state = {
    crew: [],
    total: 0,
    activePage: 10,
    limit: 50,
    offset: (offset - 1) * 10,
    searchQuery: "",
    highlighted: [],
  };

  search = (value) => {
    const { limit } = this.state;
    storage.setCurrentPage(1);

    searchService
      .getData(limit, 0, "searchByCrew", value)
      .then((data) => {
        this.setState({
          crew: !!data.crew ? getRanks(data.crew) : [],
          total: getRanks(data.crew).length,
          highlighted: getHighlightedText(data.highlighted),
        });
      })
      .catch((error) => {
        console.error(error);
      });
    this.setState({ searchQuery: value });
  };

  handlePageChange = (e, page) => {
    const { limit, searchQuery } = this.state;

    const newOffset = (page - 1) * limit;

    const currService = searchQuery ? searchService : stitchService;
    const funcName = searchQuery ? "searchByCrew" : "getCrew";

    currService
      .getData(limit, newOffset, funcName, searchQuery)
      .then((data) => {
        this.setState({
          crew: funcName === "searchByCrew" ? getRanks(data.crew) : data.crew,
          total:
            funcName === "searchByCrew"
              ? getRanks(data.crew).length
              : data.amount[0],
          highlighted:
            funcName === "searchByCrew"
              ? getHighlightedText(data.highlighted)
              : [],
        });
      })
      .catch((error) => {
        console.error(error);
      });
    storage.setCurrentPage(page);
  };

  componentDidMount() {
    const { limit, offset } = this.state;
    storage.setCurrentPage(1);

    if (searchService.searchResults) {
      searchService
        .getData(limit, 0, "searchByCrew", searchService.searchResults.query)
        .then((data) => {
          this.setState({
            crew: !!data.crew ? getRanks(data.crew) : [],
            total: getRanks(data.crew).length,
            highlighted: getHighlightedText(data.highlighted),
            searchQuery: searchService.searchResults.query,
          });
        })
        .catch((error) => {
          console.error(error);
        });
    } else {
      stitchService
        .getData(offset, limit, "getCrew")
        .then((data) => {
          this.setState({
            crew: !!data.crew ? data.crew : [],
            total: data.amount[0] || 0,
          });
        })
        .catch((error) => {
          console.error(error);
        });
    }
  }

  render() {
    const { crew, total, limit, highlighted, searchQuery } = this.state;

    return (
      <div className="crew-page">
        <SearchPanel handler={this.search} value={searchQuery}/>
        {!!crew.length ? (
          <Fragment>
            <div className="crew-header">
              <div className="crew-amount">{total} Crew Members</div>
              <button className="filter-btn">Filter</button>
            </div>
            <div className="all-crew">
              <table className="crew-table">
                <thead>
                  <tr className="string string-head">
                    <td>Name</td>
                    <td>Lisence number</td>
                    <td>Vessel</td>
                    <td>Violations</td>
                    <td>Last boarded</td>
                  </tr>
                </thead>
                <tbody>
                  {crew.map((item, ind) => (
                    <tr className="string string-body" key={ind}>
                      <td>
                        <div className="crew-box">
                          <div className="crew-name">
                            <Highlighter
                              highlightClassName="highlighted"
                              searchWords={highlighted}
                              autoEscape={true}
                              textToHighlight={item.name}
                            />
                          </div>
                          {item.rank === "captain" && (
                            <div className="captain-icon">CAPTAIN</div>
                          )}
                        </div>
                      </td>
                      <td>{item.license}</td>
                      <td>{item.vessel}</td>
                      <td>
                        {!!item.violations ? item.violations : "No violations"}
                      </td>
                      <td>
                        <div className="last-delivery-date">
                          <div className="date">
                            {moment(item.date).format("LLL")}
                          </div>
                          <div
                            className="icon"
                            style={{
                              background: `${getColor(
                                (item.safetyLevel && item.safetyLevel.level ?
                                  item.safetyLevel.level.toLowerCase() : item.safetyLevel).toLowerCase()
                              )}`,
                            }}
                          ></div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {total > limit && (
              <Pagination
                page={storage.getCurrentPage() || 1}
                count={Math.ceil(total / limit)}
                shape="rounded"
                onChange={this.handlePageChange}
              />
            )}
          </Fragment>
        ) : (
          "No crew members found"
        )}
      </div>
    );
  }
}

export default Crew;
