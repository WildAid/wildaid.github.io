import React, { memo } from "react";

const RestorePassword = () => {
  return (
    <div>Restore password page (no designs yet)</div>
  );
};

export default memo(RestorePassword);
