import React, { memo } from "react";
import moment from "moment";
import Highlighter from "react-highlight-words";

import TextViewer from "../../partials/text-viewer/text-viewer";
import { getColor } from "./../../../helpers/get-data";

import "../autofill.css";

const PreviewItem = ({ item, itemName, icon, previewName, subText, searchWords }) => {
  if (!item) return;

  const isBoardings = itemName === "Boardings";
  const name = isBoardings
    ? moment(item[previewName]).format("LLL")
    : item[previewName];
  const text =
    itemName === "Boardings"
      ? item[subText.toLowerCase()]
      : item[subText.toLowerCase()].slice(0, 2).join(", ");

  return (
    <div className="preview">
      <div className="preview-item-name">{itemName}</div>
      <div className="preview-item-info">
        <div className="preview-icon-img">
          <img
            className="preview-icon-image"
            src={require(`../../../assets/${icon}-icon.png`)}
            alt="no icon"
          />
        </div>
        <div className="preview-all-info">
          <div className="preview-name">
            <div className="name">
              <Highlighter
                highlightClassName="highlighted"
                searchWords={searchWords}
                autoEscape={true}
                textToHighlight={name}
              />
            </div>
            {isBoardings && (
              <div
                className="icon"
                style={{
                  background: getColor(
                    item.safetyLevel.level
                      ? item.safetyLevel.level.toLowerCase()
                      : item.safetyLevel.toLowerCase()
                  ),
                }}
              ></div>
            )}
          </div>
          <div className="preview-info">
            <TextViewer mainText={text} subText={subText} searchWords={searchWords}/>
            {isBoardings &&
              !!item.violations &&
              !!item.violations.length &&
              item.violations[0].offence && (
                <TextViewer
                  mainText={item.violations[0].offence.explanation}
                  subText="Violations"
                />
              )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default memo(PreviewItem);
