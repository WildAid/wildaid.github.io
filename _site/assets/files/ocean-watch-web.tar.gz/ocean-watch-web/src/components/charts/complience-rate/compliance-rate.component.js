import React, { Component } from "react";

export default class ComplianceRateChart extends Component {
  render() {
    return (
      <div className="chart-section">
        Home page with charts
      </div>
    );
  }
}
