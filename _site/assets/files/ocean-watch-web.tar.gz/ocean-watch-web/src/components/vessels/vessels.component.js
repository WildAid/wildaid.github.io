import React, { Component, Fragment } from "react";
import moment from "moment";
import Pagination from "@material-ui/lab/Pagination";
import Highlighter from "react-highlight-words";

import { getColor, getHighlightedText } from "./../../helpers/get-data";

import storage from "./../../helpers/localStorageData";

import SearchPanel from "./../partials/search-panel/search-panel.component";

import SearchService from "./../../services/search.service";
import StitchService from "./../../services/stitch.service";

import "./vessels.css";

const searchService = SearchService.getInstance();
const stitchService = StitchService.getInstance();

const offset = storage.getCurrentPage() || 1;

class Vessels extends Component {
  state = {
    vessels: [],
    total: 0,
    activePage: 10,
    limit: 50,
    offset: (offset - 1) * 10,
    searchQuery: "",
    highlighted: [],
  };

  search = (value) => {
    const { limit } = this.state;
    storage.setCurrentPage(1);

    searchService
      .getData(limit, 0, "searchByVessels", value)
      .then((data) => {
        this.setState({
          vessels: !!data.vessels ? data.vessels : [],
          total: !!data.amount[0] ? data.amount[0].total : 0,
          highlighted: getHighlightedText(data.highlighted),
        });
      })
      .catch((error) => {
        console.error(error);
      });
    this.setState({ searchQuery: value });
  };

  handlePageChange = (e, page) => {
    const { limit, searchQuery } = this.state;

    const newOffset = (page - 1) * limit;

    const currService = searchQuery ? searchService : stitchService;
    const funcName = searchQuery ? "searchByVessels" : "getVessels";

    currService
      .getData(limit, newOffset, funcName, searchQuery)
      .then((data) => {
        this.setState({
          vessels: data.vessels,
          total: data.amount[0].total,
          highlighted:
            funcName === "searchByVessels"
              ? getHighlightedText(data.highlighted)
              : [],
        });
      })
      .catch((error) => {
        console.error(error);
      });
    storage.setCurrentPage(page);
  };

  componentDidMount() {
    const { limit, offset } = this.state;
    storage.setCurrentPage(1);

    if (searchService.searchResults) {
      searchService
        .getData(limit, 0, "searchByVessels", searchService.searchResults.query)
        .then((data) => {
          this.setState({
            vessels: !!data.vessels ? data.vessels : [],
            total: !!data.amount[0] ? data.amount[0].total : 0,
            highlighted: getHighlightedText(data.highlighted),
            searchQuery: searchService.searchResults.query,
          });
        })
        .catch((error) => {
          console.error(error);
        });
    } else {
      stitchService
        .getData(limit, offset, "getVessels")
        .then((data) => {
          this.setState({ vessels: data.vessels, total: data.amount[0].total });
        })
        .catch((error) => {
          console.error(error);
        });
    }
  }

  render() {
    const { vessels, total, limit, highlighted, searchQuery } = this.state;

    return (
      <div className="vessels-page">
        <SearchPanel handler={this.search} value={searchQuery}/>
        {!!vessels.length ? (
          <Fragment>
            <div className="vessels-header">
              <div className="vessels-amount">{total} Records of Vessels</div>
              <button className="filter-btn">Filter</button>
            </div>
            <div className="all-vessels">
              <table className="vessels-table">
                <thead>
                  <tr className="string string-head">
                    <td>Vessel Name</td>
                    <td>Permit number</td>
                    <td>Nationality</td>
                    <td>Home Port</td>
                    <td>Last boarded</td>
                  </tr>
                </thead>
                <tbody>
                  {vessels.map((item, ind) => (
                    <tr className="string string-body" key={ind}>
                      <td>
                        <Highlighter
                          highlightClassName="highlighted"
                          searchWords={highlighted}
                          autoEscape={true}
                          textToHighlight={item.vessel.name}
                        />
                      </td>
                      <td>{item.vessel.permitNumber || "No number"}</td>
                      <td>
                        <div className="nationality">
                          <div className="nationality-img">
                            <img
                              className="nationality-image"
                              src={require("../../assets/nationality.png")}
                              alt="no icon"
                            />
                          </div>
                          <div className="nationality-name">
                            {item.vessel.nationality}
                          </div>
                        </div>
                      </td>
                      <td>{item.vessel.homePort}</td>
                      <td>
                        <div className="last-delivery-date">
                          <div className="date">
                            {moment(item.date).format("LLL")}
                          </div>
                          <div
                            className="icon"
                            style={{
                              background: `${getColor(
                                (item.safetyLevel && item.safetyLevel.level ?
                                  item.safetyLevel.level.toLowerCase() : item.safetyLevel).toLowerCase()
                              )}`,
                            }}
                          ></div>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {total > limit && (
              <Pagination
                page={storage.getCurrentPage() || 1}
                count={Math.ceil(total / limit)}
                shape="rounded"
                onChange={this.handlePageChange}
              />
            )}
          </Fragment>
        ) : (
          "No vessels found"
        )}
      </div>
    );
  }
}

export default Vessels;
