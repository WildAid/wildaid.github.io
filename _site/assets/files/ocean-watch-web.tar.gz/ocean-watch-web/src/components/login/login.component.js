import React, { Component } from "react";
import { Formik, Form } from "formik";
import { Grid, TextField } from "@material-ui/core";
import { withRouter } from "react-router";
import { NavLink } from "react-router-dom";

import AuthService from "../../services/auth.service";

import history from "../../root/root.history";

import { RESTORE_PASSWORD_PAGE } from "../../root/root.constants.js";

import "./login.css";

const authService = AuthService.getInstance();

class Login extends Component {
  state = {
    error: null
  };

  handleLogin = values => {
    authService
      .authenticate(values.login, values.password)
      .then(() => {
        history.replace("/home");
      })
      .catch(error => {
        console.error(error);
      });
  };

  render() {
    return (
      <Grid
        className="login-box"
        container
        direction="row"
        justify="center"
        alignItems="center"
      >
        <Grid item className="login">
          <Grid
            container
            direction="column"
            justify="center"
            alignItems="center"
          >
            <div className="login-logo">
              <img
                className="login-img"
                src={require("../../assets/login-logo.png")}
                alt="no logo"
              />
            </div>
            <Formik
              initialValues={{ login: "", password: "" }}
              onSubmit={this.handleLogin}
              render={({
                touched,
                errors,
                values,
                handleChange,
                handleBlur,
                handleSubmit,
                setFieldValue
              }) => (
                <Form className="login-form" onSubmit={handleSubmit}>
                  <TextField
                    label="Email/Username:"
                    name="login"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={e => setFieldValue("login", e.target.value)}
                    type="text"
                    value={values.login}
                  />
                  <TextField
                    label="Password:"
                    name="password"
                    type="password"
                    className="form-input"
                    onBlur={handleBlur}
                    onChange={e => setFieldValue("password", e.target.value)}
                    value={values.password}
                  />
                  <button
                    className="login-btn"
                    type="submit"
                    onClick={this.handleLogin}
                    variant="contained"
                    color="primary"
                  >
                    Log in
                  </button>
                </Form>
              )}
            />
            <NavLink className="forgot-password" to={RESTORE_PASSWORD_PAGE}>
              Forgot password?
            </NavLink>
          </Grid>
        </Grid>
      </Grid>
    );
  }
}

export default withRouter(Login);
